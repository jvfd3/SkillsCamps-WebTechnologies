import logo from "./logo.svg";
import "./App.css";
import { Link, Route, Routes } from "react-router-dom";

function App() {
  return (
    <>
      <header class="header">
        <div class="header-content responsive-wrapper">
          <div class="header-logo">
            <a href="#">
              <h3>File cloud</h3>
            </a>
          </div>
          <div class="header-navigation">
            <nav class="header-navigation-links">
              <Link to="registration">Регистрация</Link>
              <Link to="login">Вход в систему</Link>
              <Link to="upload">Загрузка файлов</Link>
            </nav>
          </div>
          <a href="#" class="button">
            <i class="ph-list-bold"></i>
            <span>Menu</span>
          </a>
        </div>
      </header>
      <main className="main">
        <Routes>
          <Route path="registration"></Route>
          <Route path="login"></Route>
          <Route path="upload"></Route>
        </Routes>
      </main>
    </>
  );
}

export default App;
